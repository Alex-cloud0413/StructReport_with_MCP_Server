"""
Driver Data MCP Server Package

智驾数据采集汇总半自动化方案的MCP Server实现包。
"""

__version__ = "0.1.0"
__author__ = "Driver Data Team"
__description__ = "智驾数据采集汇总半自动化方案"

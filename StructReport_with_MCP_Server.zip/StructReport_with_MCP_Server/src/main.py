# main.py
from fastmcp import FastMCP
import pandas as pd
import sqlite3
import json
import re
from datetime import datetime
from typing import Optional, Dict, List
import asyncio

mcp = FastMCP("driver-data-server")

# 数据库初始化
def init_database():
    conn = sqlite3.connect('driver_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS driver_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            driver_name TEXT,
            vehicle_number TEXT,
            collection_task TEXT,
            collection_segments INTEGER,
            collection_location TEXT,
            collection_date TEXT,
            collection_time_period TEXT,
            driving_distance REAL,
            raw_text TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

@mcp.tool()
async def parse_driver_report(report_text: str) -> Dict:
    """
    解析司机汇报文本，提取结构化数据
    
    Args:
        report_text: 司机的原始汇报文本
    
    Returns:
        解析后的结构化数据字典
    """
    
    # 使用LLM进行智能解析
    parsing_prompt = f"""
    请从以下司机汇报文本中提取结构化信息。司机可能会有错别字、顺序不同或缺失字段，请尽力识别：

    汇报文本：
    {report_text}

    请提取以下字段（如果某些字段缺失，请设为null）：
    - 司机姓名（采集员）
    - 车辆编号  
    - 采集任务
    - 采集段数（数字）
    - 采集地点
    - 采集日期
    - 采集时段（白天/夜晚）
    - 行驶里程（数字，单位公里）

    以JSON格式返回结果，格式如下：
    {{
        "driver_name": "张三",
        "vehicle_number": "京A12345", 
        "collection_task": "任务编号",
        "collection_segments": 5,
        "collection_location": "北京",
        "collection_date": "2025-01-10",
        "collection_time_period": "白天",
        "driving_distance": 120.5
    }}
    """
    
    # 这里调用LLM API进行解析（可以是Claude、GPT等）
    # 简化版本使用正则表达式 + 规则匹配
    extracted_data = await extract_with_rules(report_text)
    
    # 保存到数据库
    save_to_database(extracted_data, report_text)
    
    return extracted_data

async def extract_with_rules(text: str) -> Dict:
    """使用规则和正则表达式提取数据"""
    result = {
        "driver_name": None,
        "vehicle_number": None,
        "collection_task": None,
        "collection_segments": None,
        "collection_location": None,
        "collection_date": None,
        "collection_time_period": None,
        "driving_distance": None
    }
    
    # 司机姓名提取
    name_patterns = [r'采集员[：:]\s*([^，,\n]+)', r'姓名[：:]\s*([^，,\n]+)']
    for pattern in name_patterns:
        match = re.search(pattern, text)
        if match:
            result["driver_name"] = match.group(1).strip()
            break
    
    # 车辆编号提取
    vehicle_patterns = [r'车辆编号[：:]\s*([^，,\n]+)', r'车牌[：:]\s*([^，,\n]+)']
    for pattern in vehicle_patterns:
        match = re.search(pattern, text)
        if match:
            result["vehicle_number"] = match.group(1).strip()
            break
    
    # 采集任务提取
    task_patterns = [r'采集任务[：:]\s*([^，,\n]+)', r'任务[：:]\s*([^，,\n]+)']
    for pattern in task_patterns:
        match = re.search(pattern, text)
        if match:
            result["collection_task"] = match.group(1).strip()
            break
    
    # 采集段数提取（提取数字）
    segments_patterns = [r'采集段数[：:]\s*(\d+)', r'段数[：:]\s*(\d+)']
    for pattern in segments_patterns:
        match = re.search(pattern, text)
        if match:
            result["collection_segments"] = int(match.group(1))
            break
    
    # 采集地点提取
    location_patterns = [r'采集地点[：:]\s*([^，,\n]+)', r'地点[：:]\s*([^，,\n]+)']
    for pattern in location_patterns:
        match = re.search(pattern, text)
        if match:
            result["collection_location"] = match.group(1).strip()
            break
    
    # 采集日期提取
    date_patterns = [r'采集日期[：:]\s*([0-9-/]+)', r'日期[：:]\s*([0-9-/]+)']
    for pattern in date_patterns:
        match = re.search(pattern, text)
        if match:
            result["collection_date"] = match.group(1).strip()
            break
    
    # 采集时段提取
    if '白天' in text or '白' in text:
        result["collection_time_period"] = "白天"
    elif '夜晚' in text or '夜' in text:
        result["collection_time_period"] = "夜晚"
    
    # 行驶里程提取
    distance_patterns = [r'行驶里程[：:]\s*([0-9.]+)', r'里程[：:]\s*([0-9.]+)', r'([0-9.]+)\s*公里']
    for pattern in distance_patterns:
        match = re.search(pattern, text)
        if match:
            result["driving_distance"] = float(match.group(1))
            break
    
    return result

def save_to_database(data: Dict, raw_text: str):
    """保存数据到SQLite数据库"""
    conn = sqlite3.connect('driver_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO driver_reports 
        (driver_name, vehicle_number, collection_task, collection_segments, 
         collection_location, collection_date, collection_time_period, 
         driving_distance, raw_text)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        data["driver_name"], data["vehicle_number"], data["collection_task"],
        data["collection_segments"], data["collection_location"], 
        data["collection_date"], data["collection_time_period"],
        data["driving_distance"], raw_text
    ))
    conn.commit()
    conn.close()

@mcp.tool()
async def get_collection_summary() -> Dict:
    """获取采集数据总览"""
    conn = sqlite3.connect('driver_data.db')
    df = pd.read_sql_query("SELECT * FROM driver_reports", conn)
    conn.close()
    
    if df.empty:
        return {"message": "暂无数据"}
    
    summary = {
        "total_reports": len(df),
        "total_drivers": df['driver_name'].nunique(),
        "total_segments": df['collection_segments'].sum(),
        "total_distance": df['driving_distance'].sum(),
        "locations": df['collection_location'].value_counts().to_dict(),
        "time_periods": df['collection_time_period'].value_counts().to_dict(),
        "latest_update": df['created_at'].max()
    }
    
    return summary

@mcp.tool()  
async def export_data_csv() -> str:
    """导出数据为CSV格式"""
    conn = sqlite3.connect('driver_data.db')
    df = pd.read_sql_query("SELECT * FROM driver_reports", conn)
    conn.close()
    
    filename = f"driver_reports_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    df.to_csv(filename, index=False, encoding='utf-8-sig')
    
    return f"数据已导出到文件: {filename}"

if __name__ == "__main__":
    init_database()
    mcp.run()

#!/usr/bin/env python3
# HTTP API 服务器 - 为 Kiro 技能提供 REST API 接口
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import sqlite3
import pandas as pd
import json
import re
from datetime import datetime
from typing import Optional, Dict, List
import uvicorn

app = FastAPI(title="智驾数据采集 API", version="1.0.0")

class DriverReportRequest(BaseModel):
    report_text: str

class DriverReportResponse(BaseModel):
    driver_name: Optional[str]
    vehicle_number: Optional[str]
    collection_task: Optional[str]
    collection_segments: Optional[int]
    collection_location: Optional[str]
    collection_date: Optional[str]
    collection_time_period: Optional[str]
    driving_distance: Optional[float]

def extract_with_rules(text: str) -> Dict:
    """使用规则和正则表达式提取数据"""
    result = {
        "driver_name": None,
        "vehicle_number": None,
        "collection_task": None,
        "collection_segments": None,
        "collection_location": None,
        "collection_date": None,
        "collection_time_period": None,
        "driving_distance": None
    }
    
    # 司机姓名提取
    name_patterns = [r'采集员[：:]\s*([^，,\n]+)', r'姓名[：:]\s*([^，,\n]+)', r'司机[：:]\s*([^，,\n]+)']
    for pattern in name_patterns:
        match = re.search(pattern, text)
        if match:
            result["driver_name"] = match.group(1).strip()
            break
    
    # 车辆编号提取
    vehicle_patterns = [r'车辆编号[：:]\s*([^，,\n]+)', r'车牌[：:]\s*([^，,\n]+)', r'车号[：:]\s*([^，,\n]+)']
    for pattern in vehicle_patterns:
        match = re.search(pattern, text)
        if match:
            result["vehicle_number"] = match.group(1).strip()
            break
    
    # 采集任务提取
    task_patterns = [r'采集任务[：:]\s*([^，,\n]+)', r'任务[：:]\s*([^，,\n]+)', r'项目[：:]\s*([^，,\n]+)']
    for pattern in task_patterns:
        match = re.search(pattern, text)
        if match:
            result["collection_task"] = match.group(1).strip()
            break
    
    # 采集段数提取（提取数字）
    segments_patterns = [r'采集段数[：:]\s*(\d+)', r'段数[：:]\s*(\d+)', r'(\d+)\s*段']
    for pattern in segments_patterns:
        match = re.search(pattern, text)
        if match:
            result["collection_segments"] = int(match.group(1))
            break
    
    # 采集地点提取
    location_patterns = [r'采集地点[：:]\s*([^，,\n]+)', r'地点[：:]\s*([^，,\n]+)', r'位置[：:]\s*([^，,\n]+)']
    for pattern in location_patterns:
        match = re.search(pattern, text)
        if match:
            result["collection_location"] = match.group(1).strip()
            break
    
    # 采集日期提取
    date_patterns = [r'采集日期[：:]\s*([0-9-/]+)', r'日期[：:]\s*([0-9-/]+)', r'时间[：:]\s*([0-9-/]+)']
    for pattern in date_patterns:
        match = re.search(pattern, text)
        if match:
            result["collection_date"] = match.group(1).strip()
            break
    
    # 采集时段提取
    if '白天' in text or '白' in text or '上午' in text or '下午' in text:
        result["collection_time_period"] = "白天"
    elif '夜晚' in text or '夜' in text or '晚上' in text:
        result["collection_time_period"] = "夜晚"
    
    # 行驶里程提取
    distance_patterns = [r'行驶里程[：:]\s*([0-9.]+)', r'里程[：:]\s*([0-9.]+)', r'([0-9.]+)\s*公里', r'距离[：:]\s*([0-9.]+)']
    for pattern in distance_patterns:
        match = re.search(pattern, text)
        if match:
            result["driving_distance"] = float(match.group(1))
            break
    
    return result

def save_to_database(data: Dict, raw_text: str):
    """保存数据到SQLite数据库"""
    conn = sqlite3.connect('driver_data.db')
    cursor = conn.cursor()
    
    cursor.execute('''
    INSERT INTO driver_reports 
    (driver_name, vehicle_number, collection_task, collection_segments, 
     collection_location, collection_date, collection_time_period, 
     driving_distance, raw_text)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        data["driver_name"], data["vehicle_number"], data["collection_task"],
        data["collection_segments"], data["collection_location"], 
        data["collection_date"], data["collection_time_period"],
        data["driving_distance"], raw_text
    ))
    
    conn.commit()
    conn.close()

@app.get("/")
async def root():
    """API 根路径"""
    return {
        "message": "智驾数据采集 API 服务器",
        "version": "1.0.0",
        "endpoints": [
            "/rpc/parse_driver_report",
            "/rpc/get_collection_summary", 
            "/rpc/export_data_csv"
        ]
    }

@app.post("/rpc/parse_driver_report")
async def parse_driver_report(request: DriverReportRequest) -> DriverReportResponse:
    """解析司机汇报文本，提取结构化数据"""
    try:
        # 解析数据
        extracted_data = extract_with_rules(request.report_text)
        
        # 保存到数据库
        save_to_database(extracted_data, request.report_text)
        
        return DriverReportResponse(**extracted_data)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"解析失败: {str(e)}")

@app.get("/rpc/get_collection_summary")
async def get_collection_summary():
    """获取采集数据总览"""
    try:
        conn = sqlite3.connect('driver_data.db')
        df = pd.read_sql_query("SELECT * FROM driver_reports", conn)
        conn.close()
        
        if df.empty:
            return {"message": "暂无数据"}
        
        summary = {
            "total_reports": int(len(df)),
            "total_drivers": int(df['driver_name'].nunique()),
            "total_segments": int(df['collection_segments'].sum()) if not df['collection_segments'].isna().all() else 0,
            "total_distance": float(df['driving_distance'].sum()) if not df['driving_distance'].isna().all() else 0.0,
            "locations": {k: int(v) for k, v in df['collection_location'].value_counts().to_dict().items()},
            "time_periods": {k: int(v) for k, v in df['collection_time_period'].value_counts().to_dict().items()},
            "latest_update": str(df['created_at'].max())
        }
        
        return summary
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取汇总失败: {str(e)}")

@app.get("/rpc/export_data_csv")
async def export_data_csv():
    """导出数据为CSV格式"""
    try:
        conn = sqlite3.connect('driver_data.db')
        df = pd.read_sql_query("SELECT * FROM driver_reports", conn)
        conn.close()
        
        filename = f"driver_reports_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        df.to_csv(filename, index=False, encoding='utf-8-sig')
        
        return {
            "export_message": f"数据已导出到文件: {filename}",
            "filename": filename,
            "record_count": len(df)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"导出失败: {str(e)}")

@app.get("/health")
async def health_check():
    """健康检查端点"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

if __name__ == "__main__":
    print("🚀 启动智驾数据采集 API 服务器...")
    print("📍 API 文档: http://localhost:8080/docs")
    print("🔍 健康检查: http://localhost:8080/health")
    
    uvicorn.run(app, host="0.0.0.0", port=8080)
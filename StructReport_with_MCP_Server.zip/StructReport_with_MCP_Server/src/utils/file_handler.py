"""
File Handler Utility

提供文件操作相关的工具函数。
"""

import os
import shutil
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Union
import json
import csv

logger = logging.getLogger(__name__)

class FileHandler:
    """文件处理器"""
    
    def __init__(self, base_path: Optional[Union[str, Path]] = None):
        """
        初始化文件处理器
        
        Args:
            base_path: 基础路径
        """
        self.base_path = Path(base_path) if base_path else Path.cwd()
        self.logger = logger
        
    def ensure_directory(self, path: Union[str, Path]) -> Path:
        """
        确保目录存在，如果不存在则创建
        
        Args:
            path: 目录路径
            
        Returns:
            目录路径对象
        """
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        self.logger.debug(f"确保目录存在: {path}")
        return path
    
    def list_files(self, directory: Union[str, Path], pattern: str = "*") -> List[Path]:
        """
        列出目录中的文件
        
        Args:
            directory: 目录路径
            pattern: 文件匹配模式
            
        Returns:
            文件路径列表
        """
        directory = Path(directory)
        if not directory.exists():
            self.logger.warning(f"目录不存在: {directory}")
            return []
        
        files = list(directory.glob(pattern))
        self.logger.debug(f"在 {directory} 中找到 {len(files)} 个文件")
        return files
    
    def read_file(self, file_path: Union[str, Path], encoding: str = "utf-8") -> str:
        """
        读取文件内容
        
        Args:
            file_path: 文件路径
            encoding: 文件编码
            
        Returns:
            文件内容
        """
        file_path = Path(file_path)
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            self.logger.debug(f"成功读取文件: {file_path}")
            return content
        except Exception as e:
            self.logger.error(f"读取文件失败 {file_path}: {e}")
            raise
    
    def write_file(self, file_path: Union[str, Path], content: str, encoding: str = "utf-8") -> None:
        """
        写入文件内容
        
        Args:
            file_path: 文件路径
            content: 文件内容
            encoding: 文件编码
        """
        file_path = Path(file_path)
        try:
            # 确保父目录存在
            self.ensure_directory(file_path.parent)
            
            with open(file_path, 'w', encoding=encoding) as f:
                f.write(content)
            self.logger.debug(f"成功写入文件: {file_path}")
        except Exception as e:
            self.logger.error(f"写入文件失败 {file_path}: {e}")
            raise
    
    def read_json(self, file_path: Union[str, Path]) -> Dict[str, Any]:
        """
        读取JSON文件
        
        Args:
            file_path: JSON文件路径
            
        Returns:
            JSON数据
        """
        content = self.read_file(file_path)
        try:
            return json.loads(content)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON解析失败 {file_path}: {e}")
            raise
    
    def write_json(self, file_path: Union[str, Path], data: Dict[str, Any], indent: int = 2) -> None:
        """
        写入JSON文件
        
        Args:
            file_path: JSON文件路径
            data: 要写入的数据
            indent: 缩进空格数
        """
        content = json.dumps(data, ensure_ascii=False, indent=indent)
        self.write_file(file_path, content)
    
    def read_csv(self, file_path: Union[str, Path]) -> List[Dict[str, str]]:
        """
        读取CSV文件
        
        Args:
            file_path: CSV文件路径
            
        Returns:
            CSV数据列表
        """
        file_path = Path(file_path)
        try:
            with open(file_path, 'r', encoding='utf-8', newline='') as f:
                reader = csv.DictReader(f)
                data = list(reader)
            self.logger.debug(f"成功读取CSV文件: {file_path}, {len(data)} 行")
            return data
        except Exception as e:
            self.logger.error(f"读取CSV文件失败 {file_path}: {e}")
            raise
    
    def write_csv(self, file_path: Union[str, Path], data: List[Dict[str, str]], fieldnames: Optional[List[str]] = None) -> None:
        """
        写入CSV文件
        
        Args:
            file_path: CSV文件路径
            data: 要写入的数据
            fieldnames: 字段名列表
        """
        file_path = Path(file_path)
        try:
            # 确保父目录存在
            self.ensure_directory(file_path.parent)
            
            if not fieldnames and data:
                fieldnames = list(data[0].keys())
            
            with open(file_path, 'w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(data)
            self.logger.debug(f"成功写入CSV文件: {file_path}, {len(data)} 行")
        except Exception as e:
            self.logger.error(f"写入CSV文件失败 {file_path}: {e}")
            raise
    
    def copy_file(self, src: Union[str, Path], dst: Union[str, Path]) -> None:
        """
        复制文件
        
        Args:
            src: 源文件路径
            dst: 目标文件路径
        """
        src = Path(src)
        dst = Path(dst)
        
        try:
            # 确保目标目录存在
            self.ensure_directory(dst.parent)
            
            shutil.copy2(src, dst)
            self.logger.debug(f"成功复制文件: {src} -> {dst}")
        except Exception as e:
            self.logger.error(f"复制文件失败 {src} -> {dst}: {e}")
            raise
    
    def move_file(self, src: Union[str, Path], dst: Union[str, Path]) -> None:
        """
        移动文件
        
        Args:
            src: 源文件路径
            dst: 目标文件路径
        """
        src = Path(src)
        dst = Path(dst)
        
        try:
            # 确保目标目录存在
            self.ensure_directory(dst.parent)
            
            shutil.move(str(src), str(dst))
            self.logger.debug(f"成功移动文件: {src} -> {dst}")
        except Exception as e:
            self.logger.error(f"移动文件失败 {src} -> {dst}: {e}")
            raise
    
    def delete_file(self, file_path: Union[str, Path]) -> None:
        """
        删除文件
        
        Args:
            file_path: 文件路径
        """
        file_path = Path(file_path)
        try:
            if file_path.exists():
                file_path.unlink()
                self.logger.debug(f"成功删除文件: {file_path}")
            else:
                self.logger.warning(f"文件不存在: {file_path}")
        except Exception as e:
            self.logger.error(f"删除文件失败 {file_path}: {e}")
            raise
    
    def get_file_info(self, file_path: Union[str, Path]) -> Dict[str, Any]:
        """
        获取文件信息
        
        Args:
            file_path: 文件路径
            
        Returns:
            文件信息字典
        """
        file_path = Path(file_path)
        try:
            stat = file_path.stat()
            return {
                "name": file_path.name,
                "path": str(file_path),
                "size": stat.st_size,
                "created": stat.st_ctime,
                "modified": stat.st_mtime,
                "is_file": file_path.is_file(),
                "is_dir": file_path.is_dir(),
                "exists": file_path.exists()
            }
        except Exception as e:
            self.logger.error(f"获取文件信息失败 {file_path}: {e}")
            raise

"""
Utility functions for Driver Data MCP Server

提供各种工具函数，包括文件处理、数据验证等。
"""

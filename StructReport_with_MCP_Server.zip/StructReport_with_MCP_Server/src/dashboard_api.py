# dashboard_api.py
from flask import Flask, jsonify
from flask_cors import CORS
import sqlite3
import pandas as pd
from datetime import datetime

app = Flask(__name__)
CORS(app)

@app.route('/api/summary')
def get_summary():
    conn = sqlite3.connect('driver_data.db')
    df = pd.read_sql_query("SELECT * FROM driver_reports", conn)
    conn.close()
    
    if df.empty:
        return jsonify({"message": "暂无数据"})
    
    summary = {
        "total_reports": len(df),
        "total_drivers": int(df['driver_name'].nunique()),
        "total_segments": int(df['collection_segments'].sum()),
        "total_distance": float(df['driving_distance'].sum()),
        "today_reports": len(df[df['collection_date'] == datetime.now().strftime('%Y-%m-%d')]),
        "location_stats": df['collection_location'].value_counts().to_dict(),
        "time_period_stats": df['collection_time_period'].value_counts().to_dict(),
        "recent_reports": df.tail(10).to_dict('records')
    }
    
    return jsonify(summary)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

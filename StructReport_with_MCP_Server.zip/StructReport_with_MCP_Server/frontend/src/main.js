import { createApp } from 'vue'
import Dashboard from './Dashboard.vue'

// 创建Vue应用实例
const app = createApp(Dashboard)

// 挂载应用到DOM
app.mount('#app')

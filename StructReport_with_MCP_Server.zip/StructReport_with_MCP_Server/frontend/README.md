# 智驾数据采集实时看板 - 前端

## 项目说明
基于Vue.js 3构建的响应式数据看板，用于展示智驾数据采集的实时统计信息。

## 功能特性
- 📊 实时数据统计卡片
- 🍰 城市采集分布饼图
- 🍩 时段分布环形图
- 📋 最新汇报数据表格
- 🔄 30秒自动刷新

## 技术栈
- Vue.js 3
- Chart.js 4
- Vite (构建工具)

## 安装依赖
```bash
npm install
```

## 开发模式
```bash
npm run dev
```
前端将在 http://localhost:3000 启动

## 构建生产版本
```bash
npm run build
```

## 预览构建结果
```bash
npm run preview
```

## 注意事项
1. 确保后端API服务已启动 (http://localhost:5000)
2. 前端会自动连接到后端API获取数据
3. 图表使用Chart.js，支持响应式布局

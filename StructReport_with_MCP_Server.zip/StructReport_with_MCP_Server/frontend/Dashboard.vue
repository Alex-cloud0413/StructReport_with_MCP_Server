<!-- Dashboard.vue -->
<template>
  <div class="dashboard">
    <h1>智驾数据采集实时看板</h1>
    
    <div class="stats-grid">
      <div class="stat-card">
        <h3>总汇报数</h3>
        <p class="stat-number">{{ summary.total_reports }}</p>
      </div>
      
      <div class="stat-card">
        <h3>参与司机</h3>
        <p class="stat-number">{{ summary.total_drivers }}</p>
      </div>
      
      <div class="stat-card">
        <h3>总采集段数</h3>
        <p class="stat-number">{{ summary.total_segments }}</p>
      </div>
      
      <div class="stat-card">
        <h3>总里程(公里)</h3>
        <p class="stat-number">{{ summary.total_distance }}</p>
      </div>
    </div>
    
    <div class="charts-section">
      <div class="chart-container">
        <h3>各城市采集分布</h3>
        <canvas ref="locationChart"></canvas>
      </div>
      
      <div class="chart-container">
        <h3>时段分布</h3>
        <canvas ref="timeChart"></canvas>
      </div>
    </div>
    
    <div class="recent-reports">
      <h3>最新汇报</h3>
      <table>
        <thead>
          <tr>
            <th>司机</th>
            <th>车辆</th>
            <th>地点</th>
            <th>段数</th>
            <th>里程</th>
            <th>时间</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="report in summary.recent_reports" :key="report.id">
            <td>{{ report.driver_name }}</td>
            <td>{{ report.vehicle_number }}</td>
            <td>{{ report.collection_location }}</td>
            <td>{{ report.collection_segments }}</td>
            <td>{{ report.driving_distance }}</td>
            <td>{{ report.created_at }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import Chart from 'chart.js/auto'

export default {
  name: 'Dashboard',
  data() {
    return {
      summary: {},
      refreshInterval: null
    }
  },
  async mounted() {
    await this.loadData()
    this.setupCharts()
    
    // 每30秒自动刷新
    this.refreshInterval = setInterval(this.loadData, 30000)
  },
  beforeUnmount() {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval)
    }
  },
  methods: {
    async loadData() {
      try {
        const response = await fetch('http://localhost:5000/api/summary')
        this.summary = await response.json()
        this.updateCharts()
      } catch (error) {
        console.error('数据加载失败:', error)
      }
    },
    setupCharts() {
      // 位置分布图表
      const locationCtx = this.$refs.locationChart.getContext('2d')
      this.locationChart = new Chart(locationCtx, {
        type: 'pie',
        data: {
          labels: [],
          datasets: [{
            data: [],
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0']
          }]
        }
      })
      
      // 时段分布图表  
      const timeCtx = this.$refs.timeChart.getContext('2d')
      this.timeChart = new Chart(timeCtx, {
        type: 'doughnut',
        data: {
          labels: [],
          datasets: [{
            data: [],
            backgroundColor: ['#FF6384', '#36A2EB']
          }]
        }
      })
    },
    updateCharts() {
      if (this.summary.location_stats) {
        this.locationChart.data.labels = Object.keys(this.summary.location_stats)
        this.locationChart.data.datasets[0].data = Object.values(this.summary.location_stats)
        this.locationChart.update()
      }
      
      if (this.summary.time_period_stats) {
        this.timeChart.data.labels = Object.keys(this.summary.time_period_stats)
        this.timeChart.data.datasets[0].data = Object.values(this.summary.time_period_stats)
        this.timeChart.update()
      }
    }
  }
}
</script>

<style scoped>
.dashboard {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.stat-card {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  text-align: center;
}

.stat-number {
  font-size: 2em;
  font-weight: bold;
  color: #2196F3;
  margin: 0;
}

.charts-section {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 30px;
}

.chart-container {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.recent-reports {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 8px 12px;
  border-bottom: 1px solid #eee;
  text-align: left;
}

th {
  background: #f5f5f5;
  font-weight: bold;
}
</style>
